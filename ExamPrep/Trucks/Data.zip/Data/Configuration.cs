﻿namespace Trucks.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=BAGIE-PC;Database=Trucks;Trusted_Connection=True";
    }
}