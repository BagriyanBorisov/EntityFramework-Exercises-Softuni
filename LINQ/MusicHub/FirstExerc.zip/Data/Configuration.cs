﻿namespace MusicHub.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=BAGIE-PC;Database=MusicHub;Trusted_Connection=True";
    }
}
