﻿using SoftUni.Data;
using SoftUni.Models;
using System.Text;

namespace SoftUni;


public class StartUp
{
  static void Main(string[] args)
    {
        SoftUniContext dbcontext = new SoftUniContext();
        string result = AddNewAddressToEmployee(dbcontext);
        Console.WriteLine(result);
    }


    //problem 03
    public static string GetEmployeesFullInformation(SoftUniContext context)
    {
        StringBuilder sb = new StringBuilder();

        var employees = context.Employees.OrderBy(e => e.EmployeeId).Select(e => new{
            e.FirstName,
            e.LastName,
            e.MiddleName,
            e.Salary,
            e.JobTitle
        }).ToArray();

        foreach(var e in employees)
        {
            sb.AppendLine($"{e.FirstName} {e.LastName} {e.MiddleName} {e.JobTitle} {e.Salary:f2}");
        }

        return sb.ToString().TrimEnd();
    }

    //problem 04
    public static string GetEmployeesWithSalaryOver50000(SoftUniContext context) 
    {
        StringBuilder sb = new StringBuilder();

        var employees = context.Employees
            .Where(e => e.Salary > 50000)
            .OrderBy(e => e.FirstName)
            .Select(e => new{e.FirstName,e.Salary})
            .ToArray();

        foreach(var e in employees)
        {
            sb.AppendLine($"{e.FirstName} - {e.Salary:f2}");
        }


        return sb.ToString().TrimEnd();
    }

    //problem 05
    public static string GetEmployeesFromResearchAndDevelopment(SoftUniContext context)
    {
        StringBuilder sb = new StringBuilder();

        var employees = context.Employees
            .Where(e => e.Department.Name == "Research and Development")
            .OrderBy(e => e.Salary)
            .ThenByDescending(e => e.FirstName)
            .Select(e => new {e.FirstName,e.LastName,e.Salary,DepartmentName = e.Department.Name })
            .ToArray();

        foreach(var e in employees)
        {
            sb.AppendLine($"{e.FirstName} {e.LastName} from {e.DepartmentName} - ${e.Salary:f2}");
        }

        return sb.ToString().TrimEnd();
    }

    public static string AddNewAddressToEmployee(SoftUniContext context)
    {
        Address address = new Address();
        address.AddressText = "Vitoshka 15";
        address.TownId = 4;

        var searchedEmployee = context.Employees.FirstOrDefault(e => e.LastName == "Nakov");
        if(searchedEmployee != null)
        {
            context.Employees.FirstOrDefault(e => e.LastName == "Nakov").Address = address;
        }
        context.SaveChanges();

        StringBuilder sb = new StringBuilder();
        var addresses = context.Employees
            .OrderByDescending(e => e.AddressId)
            .Take(10)
            .Select(e => e.Address.AddressText);

        foreach(string a in addresses)
        {
            sb.AppendLine(a);
        }

        return sb.ToString().TrimEnd();
    }
}
