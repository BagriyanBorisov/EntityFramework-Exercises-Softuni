﻿namespace CarDealer.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=BAGIE-PC;Database=CarDealer;Integrated Security=True;Encrypt=False";
    }
}
