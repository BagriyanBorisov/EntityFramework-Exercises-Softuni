﻿namespace CarDealer.DTOs.Import
{
    public class ImportCarPartDto
    {
        public int PartId { get; set; }
    }
}
