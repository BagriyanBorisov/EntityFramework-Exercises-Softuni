﻿using BookShop.Models.Enums;

namespace BookShop;
using Data;
using Initializer;
using System.Linq;

public class StartUp
{
    public static void Main() 
        { 
            using var db = new BookShopContext();
            //DbInitializer.ResetDatabase(db);

            string command = Console.ReadLine();
            string res = GetBooksByAgeRestriction(db, command);
            Console.WriteLine(res);

        }

    public static string GetBooksByAgeRestriction(BookShopContext db, string command)
    {
        bool hasParsed = Enum.TryParse(typeof(AgeRestriction), command, true, out object? ageRestrObj);
        if (hasParsed)
        {
            AgeRestriction ageRestriction = (AgeRestriction)ageRestrObj;

            var books = db.Books.ToArray()
                .Where(b => b.AgeRestriction == ageRestriction)
                .OrderBy(b => b.Title)
                .Select(b => b.Title)
                .ToArray();
            return string.Join(Environment.NewLine, books);
        }
        return null;
    }
}



