﻿namespace Boardgames.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=BAGIE-PC;Database=Boardgames;Integrated Security=True;Encrypt=False";
    }
}
